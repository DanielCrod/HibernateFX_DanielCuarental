module com.example.hibernatefx {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.naming;
    requires javafx.graphics;
    requires java.logging;
    requires net.bytebuddy;
    requires java.sql;
    requires java.persistence;
    requires mysql.connector.java;
    requires org.hibernate.orm.core;
    opens com.example.hibernatefx.Model to org.hibernate.orm.core;

    requires org.controlsfx.controls;
    requires com.dlsc.formsfx;
    requires javafx.base;


    opens com.example.hibernatefx to javafx.fxml;
    exports com.example.hibernatefx;
}