package com.example.hibernatefx;



import com.example.hibernatefx.Model.EquipoEntity;
import com.example.hibernatefx.Model.JugadorEntity;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import org.hibernate.Session;
import org.hibernate.tool.schema.Action;

import javax.persistence.Query;
import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

import static com.example.hibernatefx.CRUD.factory;

public class HelloController implements Initializable {

    Connection con;

    static EquipoEntity eq1;

    @FXML
    private TextField nombreJugador;

    @FXML
    private Button botonBuscar;

    @FXML
    private AnchorPane panel;

    @FXML
    private Button actualizar;
    @FXML
    private TextField nombre;

    @FXML
    private TextField apellidos;

    @FXML
    private TextField posicion;

    @FXML
    private TextField dorsal;

    @FXML
    private Button aceptar;

    @FXML
    private Button limpiar;

    @FXML
    private ComboBox equipo;

    @FXML
    ListView<String> lista=new ListView<String>(TiposJugadores);

    static ObservableList<String> TiposEquipo = FXCollections.observableArrayList();

    public  static EquipoEntity  BuscarIdEquipo(String BuscarIdEquipo) {

        Session s = HibernateUtil.getSessionFactory().openSession();
        s.beginTransaction();
        Query query =  s.createQuery(" FROM EquipoEntity where nombre=:BuscarIdEquipo");

        query.setParameter("BuscarIdEquipo",BuscarIdEquipo);
        EquipoEntity equipo = (EquipoEntity) ((org.hibernate.query.Query<?>) query).uniqueResult();

        s.getTransaction().commit();
        try {
            System.out.println(equipo.getId());
        } catch (Exception e) {
            System.out.println("No se encuentra");
        }
        s.close();
        return equipo;

    }

    static ObservableList<String> TiposJugadores = FXCollections.observableArrayList();

    public static   List<String> ComboJugadores(EquipoEntity IdEquipo){
        TiposJugadores.clear();
        Session s = HibernateUtil.getSessionFactory().openSession();
        s.beginTransaction();
        Query query = s.createQuery(" FROM JugadorEntity where equipoByIdEquipo=:IdEquipo");
        query.setParameter("IdEquipo",IdEquipo);

        List <JugadorEntity> Jugadores = (List<JugadorEntity>) ((org.hibernate.query.Query<?>) query).list();

        s.getTransaction().commit();

        for(JugadorEntity jugador: Jugadores)
        {
            TiposJugadores.add(jugador.getNombre());
        }

        s.close();

        return TiposJugadores;
    }

    public static   List<String> ListaJugadores(){
        TiposJugadores.clear();
        Session s = HibernateUtil.getSessionFactory().openSession();
        s.beginTransaction();
        Query query = s.createQuery(" FROM JugadorEntity");

        List <JugadorEntity> Jugadores = (List<JugadorEntity>) ((org.hibernate.query.Query<?>) query).list();

        s.getTransaction().commit();

        for(JugadorEntity jugador: Jugadores)
        {
            TiposJugadores.add(jugador.getNombre());
        }

        s.close();

        return TiposJugadores;
    }





    public static   List<String> Jugadores(){
        TiposEquipo.clear();
        Session s = HibernateUtil.getSessionFactory().openSession();
        s.beginTransaction();
        List <EquipoEntity> Equipos =  s.createQuery(" FROM EquipoEntity").list();
        s.getTransaction().commit();

        for(EquipoEntity equipo: Equipos)
        {
            TiposEquipo.add(equipo.getNombre());


        }

        s.close();

        return TiposEquipo;

    }

    public static   List<String> ComboEquipos(){
        TiposEquipo.clear();
        Session s = HibernateUtil.getSessionFactory().openSession();
        s.beginTransaction();
        List <EquipoEntity> Equipos =  s.createQuery(" FROM EquipoEntity").list();
        s.getTransaction().commit();

        for(EquipoEntity equipo: Equipos)
        {
            TiposEquipo.add(equipo.getNombre());


        }

        s.close();

        return TiposEquipo;

    }


    @FXML
    public void nuevo(ActionEvent Event) {
        nombre.setDisable(false);
        apellidos.setDisable(false);
        dorsal.setDisable(false);
        posicion.setDisable(false);
        equipo.setDisable(false);
    }

    /*@FXML
    public void actualizar(ActionEvent Event) {
        EquipoEntity a;
        a = BuscarIdEquipo(equipo.getValue().toString());
        lista.setItems((ObservableList<String>) ComboJugadores(a));
    }*/
    @FXML
    public void itemStateChanged(ActionEvent e) {
        if (e.getSource()==equipo) {
            String seleccionado=(String)equipo.getValue().toString();
             EquipoEntity a;
             a = BuscarIdEquipo(seleccionado);
            lista.setItems((ObservableList<String>) ComboJugadores(a));
        }
    }


    @FXML
    public void buscarJugador(ActionEvent event) {
        int id = Integer.parseInt(nombreJugador.getText());
        JugadorEntity jugador = CRUD.getJugadorByNombre(id);
        if (jugador == null) {
            System.out.println("Lo siento! Ese usuario NO EXISTE.");
        } else {
            jugador.setNombre(nombre.getText());
            jugador.setApellidos(apellidos.getText());
            int dors = Integer.parseInt(dorsal.getText());
            jugador.setDorsal(dors);
            jugador.setPosicion(posicion.getText());
            CRUD.modJugador(jugador);
            System.out.println(jugador.toString());
        }
    }
    @FXML
    public void modificar(ActionEvent Event) {
        panel.setVisible(true);
        nombre.setDisable(false);
        apellidos.setDisable(false);
        dorsal.setDisable(false);
        posicion.setDisable(false);
        equipo.setDisable(false);
    }

    @FXML
    public void eliminar(ActionEvent Event) {
        String equipo = (String)this.lista.getSelectionModel().getSelectedItem();
        CRUD.eliminarJugador(equipo);
        EquipoEntity a;
        a = BuscarIdEquipo("Real Madrid");
        lista.setItems((ObservableList<String>) ComboJugadores(a));
    }

    @FXML
    public void limpiar(ActionEvent Event) {
        nombre.setText("");
        apellidos.setText("");
        dorsal.setText("");
        posicion.setText("");
    }

    @FXML
    public void aceptar(ActionEvent Event) {
        try {
            int dors = Integer.parseInt(dorsal.getText());
            EquipoEntity a;
            a = BuscarIdEquipo(equipo.getValue().toString());
            JugadorEntity j = new JugadorEntity(nombre.getText(), apellidos.getText(), dors, posicion.getText(), a);
            CRUD.guardarJugador(j);
        } catch (Exception e) {
            System.out.println("Error");
        }
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        equipo.getItems().addAll(ComboEquipos());
        EquipoEntity a;
        a = BuscarIdEquipo("Real Madrid");
        lista.setItems((ObservableList<String>) ComboJugadores(a));
    }
}