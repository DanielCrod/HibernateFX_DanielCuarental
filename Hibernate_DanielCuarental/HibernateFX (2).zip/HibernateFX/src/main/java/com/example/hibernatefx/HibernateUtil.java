package com.example.hibernatefx;


import com.example.hibernatefx.Model.EquipoEntity;
import com.example.hibernatefx.Model.JugadorEntity;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class HibernateUtil {
    static SessionFactory factory = null;

    public HibernateUtil() {
    }

    public static SessionFactory getSessionFactory() {
        return factory;
    }

    public static Session getSession() {
        return factory.openSession();
    }

    static {
        Configuration cfg = new Configuration();
        cfg.configure("hibernate.cfg.xml");
        cfg.addAnnotatedClass(JugadorEntity.class);
        cfg.addAnnotatedClass(EquipoEntity.class);
        factory = cfg.buildSessionFactory();
    }
}
