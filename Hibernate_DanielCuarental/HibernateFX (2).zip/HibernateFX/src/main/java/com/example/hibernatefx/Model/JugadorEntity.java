package com.example.hibernatefx.Model;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "jugador", schema = "hibernate", catalog = "")
public class JugadorEntity {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "id")
    private int id;
    @Basic
    @Column(name = "nombre")
    private String nombre;
    @Basic
    @Column(name = "apellidos")
    private String apellidos;
    @Basic
    @Column(name = "dorsal")
    private Integer dorsal;
    @Basic
    @Column(name = "posicion")
    private String posicion;
    @ManyToOne
    @JoinColumn(name = "idEquipo", referencedColumnName = "id")
    private EquipoEntity equipoByIdEquipo;

    public JugadorEntity (String nombre, String apellidos, Integer dorsal, String posicion, EquipoEntity equipoByIdEquipo) {
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.dorsal = dorsal;
        this.posicion = posicion;
        this.equipoByIdEquipo = equipoByIdEquipo;
    }

    public JugadorEntity() {

    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public Integer getDorsal() {
        return dorsal;
    }

    public void setDorsal(Integer dorsal) {
        this.dorsal = dorsal;
    }

    public String getPosicion() {
        return posicion;
    }

    public void setPosicion(String posicion) {
        this.posicion = posicion;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        JugadorEntity jugador = (JugadorEntity) o;
        return id == jugador.id && Objects.equals(nombre, jugador.nombre) && Objects.equals(apellidos, jugador.apellidos) && Objects.equals(dorsal, jugador.dorsal) && Objects.equals(posicion, jugador.posicion);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, nombre, apellidos, dorsal, posicion);
    }

    public EquipoEntity getEquipoByIdEquipo() {
        return equipoByIdEquipo;
    }

    public void setEquipoByIdEquipo(EquipoEntity equipoByIdEquipo) {
        this.equipoByIdEquipo = equipoByIdEquipo;
    }
}
