package com.example.hibernatefx;


import com.example.hibernatefx.Model.EquipoEntity;
import com.example.hibernatefx.Model.JugadorEntity;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.temporal.JulianFields;
import java.util.ArrayList;


public class CRUD {

    static SessionFactory factory = HibernateUtil.getSessionFactory();



    public static void modJugador(JugadorEntity jugador) {
        Transaction transaction = null;
        try(Session session = factory.openSession()) {
            transaction = session.beginTransaction();
            session.saveOrUpdate(jugador);
            transaction.commit();
        } catch (Exception e) {
            if(transaction != null)
                transaction.rollback();
        }
    }

    public static void guardarJugador(JugadorEntity jugador) {
        Transaction transaction = null;
        try(Session session = factory.openSession()) {
            transaction = session.beginTransaction();
            session.save(jugador);
            transaction.commit();
        } catch (Exception e) {
            if(transaction != null)
                transaction.rollback();
        }
    }

    public static JugadorEntity getJugadorByNombre(int id) {
        Transaction transaction = null;
        JugadorEntity jugador = null;
        try(Session session = factory.openSession()) {
            transaction = session.beginTransaction();
            jugador = session.get(JugadorEntity.class, id);
            transaction.commit();
        } catch (Exception e) {

            if(transaction != null)
                transaction.rollback();
        }
        return jugador;
    }

    public static void eliminarJugador(String jugador) {
        Transaction transaction = null;
        try(Session session = factory.openSession()) {
            transaction = session.beginTransaction();
            JugadorEntity jugad = (JugadorEntity)session.createQuery("FROM JugadorEntity where nombre='" + jugador + "'").uniqueResult();
            session.remove(jugad);
            transaction.commit();
        } catch (Exception e) {
            if(transaction != null)
                transaction.rollback();
        }
    }

    public static void seleccionarEquipo() {
        Transaction transaction = null;
        try(Session session = factory.openSession()) {
            transaction = session.beginTransaction();
            session.createQuery("FROM EquipoEntity");
            session.close();
        }
    }

    public ArrayList getListaEquipos() {
        ArrayList equipos = new ArrayList();
        EquipoEntity equipo = null;
        Statement consulta;
        ResultSet resultado;

        try (Session session = factory.openSession()){
            resultado = (ResultSet) session.createQuery("SELECT nombre from EquipoEntity");

            while (resultado.next()) {
                equipo = new EquipoEntity();
                equipo.setId(resultado.getInt("id"));
                equipo.setNombre(resultado.getString("nombre"));
                equipos.add(equipo);
            }
        } catch (SQLException e) {
        }
        return equipos;
    }
}
